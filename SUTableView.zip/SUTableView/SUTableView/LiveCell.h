//
//  LiveCell.h
//  SUTableView
//
//  Created by KevinSu on 16/8/6.
//  Copyright © 2016年 KevinSu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LiveCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *descLabel;

@end

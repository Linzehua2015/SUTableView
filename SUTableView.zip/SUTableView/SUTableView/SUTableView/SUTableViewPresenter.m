//
//  SUTableViewPresenter.m
//  SUTableView
//
//  Created by 林泽华 on 2018/10/9.
//  Copyright © 2018 KevinSu. All rights reserved.
//

#import "SUTableViewPresenter.h"

@implementation SUTableViewPresenter

#pragma mark - Delegate Method Override
- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger originalRows = [self.originalDataSource tableView:tableView numberOfRowsInSection:section];
    return originalRows * 3;
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger originalRows = [self.originalDataSource tableView:tableView numberOfRowsInSection:indexPath.section];
    NSInteger originalRow = indexPath.row % originalRows;
    NSIndexPath *oroginalIndexPath = [NSIndexPath indexPathForRow:originalRow inSection:indexPath.section];
    return [self.originalDataSource tableView:tableView cellForRowAtIndexPath:oroginalIndexPath];
}

#pragma mark - forward & response override
- (id)forwardingTargetForSelector:(SEL)aSelector { 
    if ([self.originalDataSource respondsToSelector:aSelector]) return self.originalDataSource;
    return [super forwardingTargetForSelector:aSelector];
}

@end

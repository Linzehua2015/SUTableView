//
//  SUTableViewPresenter.h
//  SUTableView
//
//  Created by 林泽华 on 2018/10/9.
//  Copyright © 2018 KevinSu. All rights reserved.
//

#import <UIKit/UIKit.h> 

@interface SUTableViewPresenter : NSObject <UITableViewDataSource>

@property (nonatomic, weak) id<UITableViewDataSource> originalDataSource;

@end


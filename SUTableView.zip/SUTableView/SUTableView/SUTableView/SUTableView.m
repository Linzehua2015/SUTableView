//
//  SUTableView.m
//  ZHIBO
//
//  Created by 万众科技 on 16/7/28.
//  Copyright © 2016年 WanZhong. All rights reserved.
//

#import "SUTableView.h"
#import "SUTableViewPresenter.h"

@interface SUTableView ()

@property (nonatomic, strong) SUTableViewPresenter * presenter;

@end

@implementation SUTableView

#pragma mark - LayoutSubviews Override
- (void)layoutSubviews {
    [self resetContentOffsetIfNeeded];
    [super layoutSubviews];
}

- (void)resetContentOffsetIfNeeded {
    CGPoint contentOffset  = self.contentOffset;
    //scroll over top
    if (contentOffset.y < 0.0) {
        contentOffset.y = self.contentSize.height / 3.0;
    }
    //scroll over bottom
    else if (contentOffset.y >= (self.contentSize.height - self.bounds.size.height)) {
        contentOffset.y = self.contentSize.height / 3.0 - self.bounds.size.height;
    }
    [self setContentOffset: contentOffset];
}

#pragma mark - DataSource Delegate Setter/Getter Override
- (void)setDataSource:(id<UITableViewDataSource>)dataSource {
    self.presenter.originalDataSource = dataSource;
    [super setDataSource:self.presenter];
}

#pragma mark - Get

- (SUTableViewPresenter *)presenter {
    if (!_presenter) {
        _presenter = [[SUTableViewPresenter alloc] init];
    }
    return _presenter;
}

@end
